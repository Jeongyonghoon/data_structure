#include "CarNode.h"
#include<cstring>

CarNode::CarNode()
{
}

CarNode::~CarNode()//destructor
{
	/* You must fill here */
}