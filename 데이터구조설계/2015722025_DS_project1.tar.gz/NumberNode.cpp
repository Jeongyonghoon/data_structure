#include "NumberNode.h"


NumberNode::~NumberNode()//destructor
{
	/* You must fill here */
}
